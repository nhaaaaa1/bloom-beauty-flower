from flask import Flask, render_template, request, flash, redirect, url_for
import requests

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

# Telegram Bot Info
TOKEN = "8429689872:AAFM2FjlcpNrQObzeLErl0X6rI1wBb8XU2w"
CHAT_ID = "@testlg_channel1"  # or your user ID if it's a private chat
BASE_URL = f"https://api.telegram.org/bot{TOKEN}/sendMessage"

# Sample product data
products = [
    {
        'id': 1,
        'name': 'Red Roses Bouquet',
        'price': 49.99,
        'image': 'roses.jpg',
        'category': 'romantic',
        'description': 'Beautiful red roses perfect for romantic occasions',
        'details': '12 fresh red roses with baby breath and greenery, delivered in elegant packaging.'
    },
    {
        'id': 2,
        'name': 'Sunflower Arrangement',
        'price': 39.99,
        'image': 'sunflowers.jpg',
        'category': 'cheerful',
        'description': 'Bright sunflowers to bring sunshine to any room',
        'details': '5 large sunflowers with seasonal greens in a rustic vase.'
    },
    {
        'id': 3,
        'name': 'Orchid Plant',
        'price': 34.99,
        'image': 'orchid.jpg',
        'category': 'elegant',
        'description': 'Elegant orchid plant for sophisticated decor',
        'details': 'Beautiful purple orchid in a ceramic pot, perfect for home or office.'
    },
    {
        'id': 4,
        'name': 'Mixed Spring Bouquet',
        'price': 45.99,
        'image': 'spring.jpg',
        'category': 'seasonal',
        'description': 'Colorful mix of spring flowers',
        'details': 'Seasonal flowers including tulips, daffodils, and hyacinths.'
    }
]


def send_telegram_message(message):
    """Send notification to Telegram channel"""
    payload = {
        'chat_id': CHAT_ID,
        'text': message,
        'parse_mode': 'HTML'
    }

    try:
        response = requests.post(BASE_URL, json=payload)
        if response.status_code != 200:
            print("Telegram Error:", response.text)
            return False
        return True
    except Exception as e:
        print(f"Error sending Telegram message: {e}")
        return False


@app.route('/')
def index():
    return render_template('index.html', products=products)


@app.route('/product/<int:product_id>')
def product_details(product_id):
    product = next((p for p in products if p['id'] == product_id), None)
    if product is None:
        flash('Product not found!', 'error')
        return redirect(url_for('index'))
    return render_template('product_details.html', product=product)


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')

        if not all([name, email, subject, message]):
            flash('Please fill in all fields!', 'error')
            return render_template('contact.html')

        telegram_message = f"""
🆕 <b>New Contact Form Submission</b>

👤 Name: {name}
📧 Email: {email}
📝 Subject: {subject}
💬 Message: {message}
        """

        if send_telegram_message(telegram_message):
            flash('Your message has been sent to our Telegram. Thank you!', 'success')
        else:
            flash('Something went wrong. Please try again later.', 'error')

        return redirect(url_for('contact'))

    return render_template('contact.html')


if __name__ == '__main__':
    app.run(debug=True)
